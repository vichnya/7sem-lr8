from setuptools import setup
setup(install_requires=[
    'djangorestframework',
    'django-filter',
    'django-cors-headers==3.10.0',
    'django-crispy-forms==1.12.0'
])